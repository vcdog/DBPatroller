#!/bin/bash

# ----------------------------------------------------------------
#	Copyright © 2024 SUNACYW Ltd. All rights reserved.
#	FileName   : DBPatroller.sh
#	Author     : dba
#	Mail       : dba@sunacwy.com.cn
#	Version    : v1.0.0
#	CreateTime : 2024-05-27 16:16:48
#	COPYRIGHT  : Copyright ©2024 - 融创服务
#	Description: Welcome Use The Script.
# ----------------------------------------------------------------



tee /tmp/dbpatroller_report_mysql.html;


delimiter $MY_LHRXXT
system echo '<html lang="en"><head><title>MySQL Report</title> <style type="text/css">' > /tmp/dbpatroller_report_mysql.html
system echo 'body.awr {font:bold 10pt Courier New,Helvetica,sans-serif;color:black;background:White;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'table  {font:11px Courier New,Helvetica,sans-serif; color:Black; background:#FFFFCC; padding:1px; margin:0px 0px 0px 0px; cellspacing:0px;border-collapse:collapse;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'th  {font:bold 11px Courier New,Helvetica,sans-serif; color:White; background:#0066cc; padding:2px; cellspacing:0px;border-collapse:collapse;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'td {font-family:Courier New; word-wrap: break-word; white-space: pre-wrap; white-space: -moz-pre-wrap;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'tr:nth-child(odd){background:White;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'h1.awr     {font:bold 20pt Courier New,Helvetica,sans-serif;color:#336699;background-color:White;border-bottom:1px solid #cccc99;margin-top:0pt; margin-bottom:0pt;padding:0px 0px 0px 0px;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'h2.awr     {font:bold 16pt Courier New,Helvetica,sans-serif;color:#336699;background-color:White;margin-top:0pt; margin-bottom:0pt;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'th.awrbg   {font:bold 10pt Courier New,Helvetica,sans-serif; color:White; background:#0066CC;padding-left:0px; padding-right:0px;padding-bottom:0px}' >> /tmp/dbpatroller_report_mysql.html
system echo 'th.awrnc   {font:9pt Courier New,Helvetica,sans-serif;color:black;background:White;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'th.awrc    {font:9pt Courier New,Helvetica,sans-serif;color:black;background:#FFFFCC;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'td.awrnc   {font:9pt Courier New,Helvetica,sans-serif;color:black;background:White;vertical-align:middle;padding:4;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'a.info:hover {background:#eee;color:#000000; position:relative;}' >> /tmp/dbpatroller_report_mysql.html
system echo 'a.info span {display: none; }' >> /tmp/dbpatroller_report_mysql.html
system echo 'a.info:hover span {font-size:11px!important; color:#000000; display:block;position:absolute;top:30px;left:40px;width:150px;border:1px solid #ff0000; background:#FFFF00; padding:1px 1px;text-align:left;word-wrap: break-word; white-space: pre-wrap; white-space: -moz-pre-wrap}' >> /tmp/dbpatroller_report_mysql.html
system echo 'td.awrc    {font:9pt Courier New,Helvetica,sans-serif;color:black;background:#FFFFCC; vertical-align:middle;padding:4;}</style></head>' >> /tmp/dbpatroller_report_mysql.html
system echo '<body class="awr">' >> /tmp/dbpatroller_report_mysql.html

system echo '<Marquee  align="absmiddle" scrolldelay="100" behavior="alternate" direction="left" onmouseover="this.stop()" onmouseout="this.start()" bgcolor="#FFCC00"  height=18 width=100%  vspace="1" hspace="1"><font face="Courier New,Helvetica,Geneva,sans-serif" color="#008B00" size="2"> <div style="font-weight:lighter">巡检人:SUNAC-基础架构平台数据组 此报告数据库组有最终解释权</div></font></Marquee>' >> /tmp/dbpatroller_report_mysql.html


system echo '<center><font size=+3 color=darkgreen><b>MySQL数据库巡检报告</b></font></center>' >> /tmp/dbpatroller_report_mysql.html



-- +----------------------------------------------------------------------------+
-- +----------------------------------------------------------------------------+
-- |                             - REPORT HEADER -                              |
-- +----------------------------------------------------------------------------+


system echo '<a name=top></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<a name="directory"><font size=+2 face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 1 引言</b></font></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
system echo '<a style="font-weight:lighter">巡 检 人：SUNAC-基础架构平台数据组</a></br>' >> /tmp/dbpatroller_report_mysql.html
system echo -e "<a style=\"font-weight:lighter\">巡检时间:" >> /tmp/dbpatroller_report_mysql.html
system echo `date "+%Y-%m-%d %H:%M:%S"` >> /tmp/dbpatroller_report_mysql.html
system echo ' </a></br>' >> /tmp/dbpatroller_report_mysql.html
system echo '<a style="font-weight:lighter">修改日期：2024-03-18 09:00:01</a></br>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
system echo '[<a class="noLink" href="#html_bottom_link"  style="font-weight:lighter">转到页底</a>]' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr>' >> /tmp/dbpatroller_report_mysql.html

 

system echo '<a name="directory"><font size=+2 face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 2 目录</b></font></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<table width="100%" border="1" bordercolor="#000000" cellspacing="0px" style="border-collapse:collapse; margin-top:0.3cm;" align="center">' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td style="background-color:#FFCC00" rowspan="2"  nowrap align="center" width="10%"><a class="info" href="#db_info_link"><font size=+0.5 face="Courier New,Helvetica,sans-serif" color="#000000"><b>总体概况</b><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" width="18%"  style="background-color:#FFFFCC" ><a class="info" href="#db_base_info"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">数据库基本信息<span>数据库的总体概况、版本、主机情况、数据库负载情况、数据库属性等</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#all_db_and_size"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">所有数据库及其容量大小<span>当前数据库实例的所有数据库及其容量大小</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#db_status"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">查看数据库的运行状态<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#no_primary_tb"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">没有主键的表<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#top10_tb_size"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">占用空间最大的前10张大表<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html 

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#top10_idx_size"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">占用空间最大的前10个索引<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#all_engines"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">所有存储引擎列表<span>当前数据库实例的所有存储引擎列表</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#ALL_USES"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">查询所有用户<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#IMPORTANT_INIT"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">一些重要的参数<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#ck_user_login"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">多维度查看用户登录信息<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699"><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td style="background-color:#FFCC00" rowspan="2"  nowrap align="center" width="10%"><a class="info" href="#lOCK_INFO"><font size=+0.5 face="Courier New,Helvetica,sans-serif" color="#000000"><b>锁情况</b><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#all_processlist"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">查询所有线程<span>排除sleep线程</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#all_processlist_sleep"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">sleep线程TOP20<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#process_use"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">当前是否有锁表<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#process_use"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">行锁争用情况<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#Innodb_running"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">InnoDB存储引擎的运行时信息<span>查询InnoDB存储引擎的运行时信息，包括死锁的详细信息</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#innodb_trx_info"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">当前状态产生的InnoDB锁<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#innodb_trx_active"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">当前Innodb内核中的当前活跃事务<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#innodb_lock_detail"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">锁详情<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#mdl_info"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">元数据锁的相关信息<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#mdl_status"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">查看锁参数的状态<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td style="background-color:#FFCC00" rowspan="2"  nowrap align="center" width="10%"><a class="info" href="#sql_info"><font size=+0.5 face="Courier New,Helvetica,sans-serif" color="#000000"><b>SQL部分</b><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#SQL_run_long"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">跟踪长时间操作的进度<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#SQL_run_long_95"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">平均执行时间值大于95%的平均执行时间的语句<span>查看平均执行时间值大于95%的平均执行时间的语句（可近似地认为是平均执行时间超长的语句），默认情况下按照语句平均延迟(执行时间)降序排序</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sql_info_tmp1"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">使用了临时表的语句<span>查看使用了临时表的语句，默认情况下按照磁盘临时表数量和内存临时表数量进行降序排序</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sql_info_tmp2"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">使用了临时表的语句<span>查看使用了临时表的语句，默认情况下按照磁盘临时表数量和内存临时表数量进行降序排序</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sql_info_disk_sort"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">查看执行了文件排序的语句<span>默认情况下按照语句总延迟时间（执行时间）降序排序</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sqL_cost_all"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">查询SQL的整体消耗百分比<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sqL_exec_count_top10"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">执行次数Top10<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sqL_full_scan"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">使用全表扫描的SQL语句<span>使用全表扫描的SQL语句</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sql_no_best_index"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">没有使用到最优索引的语句<span>查看全表扫描或者没有使用到最优索引的语句（经过标准化转化的语句文本），默认情况下按照全表扫描次数与语句总次数百分比和语句总延迟时间(执行时间)降序排序</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sql_error_worings"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">产生错误或警告的语句<span>查看产生错误或警告的语句，默认情况下，按照错误数量和警告数量降序排序</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699"><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td style="background-color:#FFCC00" rowspan="1"  nowrap align="center" width="10%"><a class="info" href="#index_info"><font size=+0.5 face="Courier New,Helvetica,sans-serif" color="#000000"><b>索引部分</b><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sql_redundant_indexes"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">冗余索引<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#sql_unused_indexes"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">无效索引（从未使用过的索引）<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#index_qfd"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">索引区分度<span>区分度，越接近1，表示区分度越高，低于0.1，则说明区分度较差，开发者应该重新评估SQL语句涉及的字段，选择区分度高的多个字段创建索引</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#spfile_contents"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699"><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#statistics_level"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699"><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td style="background-color:#FFCC00" rowspan="1"  nowrap align="center" width="10%"><a class="info" href="#slave_info"><font size=+0.5 face="Courier New,Helvetica,sans-serif" color="#000000"><b>主从情况</b><span> MySQL Replication（MySQL主从复制）</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#SLAVE_IMPORTANT_INIT"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">主从复制涉及到的重要参数<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#slave_processlist"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">主从库同步状态<span>主从库同步查询</span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#master_info_status"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">主库状态监测<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#slave_info_status"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">从库状态监测<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#mgr_info_status"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">MGR集群状态监测<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html

system echo '<tr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td style="background-color:#FFCC00" rowspan="1"  nowrap align="center" width="10%"><a class="info" href="#db_performance_info"><font size=+0.5 face="Courier New,Helvetica,sans-serif" color="#000000"><b>数据库性能</b><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#db_per_config_stats"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">性能参数统计<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#Auto_increment"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">自增ID的使用<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#tmpdir"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699">tmpdir路径检查<span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699"><span></span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699"><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '<td nowrap align="center" style="background-color:#FFFFCC" ><a class="info" href="#"><font size=2.5 face="Courier New,Helvetica,sans-serif" color="#336699"><span> </span></font></a></td>' >> /tmp/dbpatroller_report_mysql.html
system echo '</tr>' >> /tmp/dbpatroller_report_mysql.html


system echo '</table>' >> /tmp/dbpatroller_report_mysql.html


system echo '<br />' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<br />' >> /tmp/dbpatroller_report_mysql.html



-- +----------------------------------------------------------------------------+
-- +----------------------------------------------------------------------------+
-- |                             - DATABASE OVERVIEW -                          |
-- +----------------------------------------------------------------------------+


system echo '<a name="db_info_link"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<font size="+2" color="00CCFF"><b>3.1 数据库总体概况</b></font><hr align="left" width="800">' >> /tmp/dbpatroller_report_mysql.html


delimiter ;
system echo '<a name="db_base_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.1 数据库基本信息</b></font>' >> /tmp/dbpatroller_report_mysql.html
-- set GLOBAL show_compatibility_56=1;
SELECT  now(),
	USER(), -- USER()、 SYSTEM_USER()、 SESSION_USER()、 
	CURRENT_USER(),
	CONNECTION_ID(),
	DATABASE(), -- SCHEMA(),
	version() Server_version,
	( SELECT sum( TRUNCATE ( ( data_length + index_length ) / 1024 / 1024, 2 ) ) AS 'all_db_size(MB)' FROM information_schema.TABLES b ) all_db_size_MB,
	(select truncate(sum(total_extents*extent_size)/1024/1024,2) from  information_schema.FILES b) all_datafile_size_MB,
	( SELECT @@datadir ) datadir,
	( SELECT @@SOCKET ) SOCKET,
	( SELECT @@log_error ) log_error,
	-- ( SELECT @@tx_isolation ) tx_isolation, -- SELECT @@transaction_isolation tx_isolation
	( SELECT @@autocommit ) autocommit,
	( SELECT @@log_bin ) log_bin,
	( SELECT @@server_id ) server_id;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 版本信息和数据库内存</b></font>' >> /tmp/dbpatroller_report_mysql.html
select version() as 'DB_version',truncate(@@innodb_buffer_pool_size/1024/1024/1024,2) as innodb_buffer_pool_size_GB;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 进程数状态</b></font>' >> /tmp/dbpatroller_report_mysql.html
show global status like 'Thread%';


-- notee
-- tee /tmp/dbpatroller_report_mysql.html;
-- system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
-- SHOW PLUGINS;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="all_db_and_size"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.2 当前数据库实例的所有数据库及其容量大小</b></font>' >> /tmp/dbpatroller_report_mysql.html
-- show databases;
SELECT
  a.SCHEMA_NAME,
  a.DEFAULT_CHARACTER_SET_NAME,
  a.DEFAULT_COLLATION_NAME,
  SUM(table_rows) AS table_rows,
  TRUNCATE(SUM(data_length) / 1024 / 1024 / 1024,2) AS data_size_GB,
  TRUNCATE(SUM(index_length) / 1024 / 1024 / 1024,2) AS index_size_GB,
  TRUNCATE(SUM(data_length + index_length) / 1024 / 1024 / 1024,2) AS all_size_GB,
  -- TRUNCATE(SUM(max_data_length) / 1024 / 1024 / 1024,2) AS max_size_GB,
  TRUNCATE(SUM(data_free) / 1024 / 1024 / 1024, 2) AS free_size_GB,
  MAX(f.filesize_G) AS disk_size_mb
FROM
  INFORMATION_SCHEMA.SCHEMATA a
  LEFT JOIN information_schema.tables b
    ON a.SCHEMA_NAME = b.TABLE_SCHEMA
  LEFT JOIN
    (SELECT
      SUBSTRING_INDEX(SUBSTRING_INDEX(b.file_name, '/', - 2),'/',1) AS db_name,
      TRUNCATE(
        SUM(total_extents * EXTENT_SIZE) / 1024 / 1024 / 1024,
        2
      ) filesize_G 
      -- select file_name,
      -- SUBSTRING_INDEX(substring_index(b.file_name,'/',-2),'/',1)
     FROM
      information_schema.FILES b
    WHERE b.file_type NOT IN ('UNDO LOG')
    GROUP BY SUBSTRING_INDEX(SUBSTRING_INDEX(b.file_name, '/', - 2),'/',1) 
    ) f
    ON (a.SCHEMA_NAME = f.db_name)
WHERE a.schema_name NOT IN (
    'mysql',
    'information_schema',
    'performance_schema',
    'sys',
    '__recycle_bin__'
  )
GROUP BY a.SCHEMA_NAME,
  a.DEFAULT_CHARACTER_SET_NAME,
  a.DEFAULT_COLLATION_NAME
ORDER BY SUM(data_length) DESC,
  SUM(index_length) DESC;




notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="all_db_objects"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.3 数据库对象</b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT
  db AS db_name,
  TYPE AS ob_type,
  cnt AS sums
FROM
  (SELECT
    'TABLE' TYPE,
    table_schema db,
    COUNT(*) cnt
  FROM
    information_schema.`TABLES` a
  WHERE table_type = 'BASE TABLE'
    AND a.TABLE_SCHEMA NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
    )
  GROUP BY table_schema
  UNION
  ALL
  SELECT
    'EVENTS' TYPE,
    event_schema db,
    COUNT(*) cnt
  FROM
    information_schema.`EVENTS` b
  WHERE b.event_schema NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
    )
  GROUP BY event_schema
  UNION
  ALL
  SELECT
    'TRIGGERS' TYPE,
    trigger_schema db,
    COUNT(*) cnt
  FROM
    information_schema.`TRIGGERS` c
  WHERE c.trigger_schema NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
    )
  GROUP BY trigger_schema
  UNION
  ALL
  SELECT
    'PROCEDURE' TYPE,
    routine_schema db,
    COUNT(*) cnt
  FROM
    information_schema.ROUTINES d
  WHERE `ROUTINE_TYPE` = 'PROCEDURE'
    AND d.routine_schema NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
    )
  GROUP BY db
  UNION
  ALL
  SELECT
    'FUNCTION' TYPE,
    routine_schema db,
    COUNT(*) cnt
  FROM
    information_schema.ROUTINES d
  WHERE `ROUTINE_TYPE` = 'FUNCTION'
    AND d.routine_schema NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
    )
  GROUP BY db
  UNION
  ALL
  SELECT
    'VIEWS' TYPE,
    TABLE_SCHEMA db,
    COUNT(*) cnt
  FROM
    information_schema.VIEWS f
  WHERE 1 = 1
    AND f.TABLE_SCHEMA NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
    )
  GROUP BY table_schema) t
ORDER BY db,TYPE;




notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="db_status"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.4 查看数据库的运行状态</b></font>' >> /tmp/dbpatroller_report_mysql.html
delimiter $MY_LHRXXT
system echo '<TABLE BORDER=1><tr><td style="background:#FFFFCC;font-family:Courier New; word-wrap: break-word; white-space: pre-wrap; white-space: -moz-pre-wrap">' >> /tmp/dbpatroller_report_mysql.html
delimiter ;
status;
notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '</TD></TR></TABLE>' >> /tmp/dbpatroller_report_mysql.html

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="no_primary_tb"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.5 没有主键的表</b></font>' >> /tmp/dbpatroller_report_mysql.html
-- 没有主键的表
SELECT
  table_schema,
  table_name
FROM
  information_schema.tables
WHERE table_type = 'BASE TABLE'
  AND (table_schema, table_name) NOT IN
  (SELECT
    /*+ subquery(materialization) */
    a.TABLE_SCHEMA,
    a.TABLE_NAME
  FROM
    information_schema.TABLE_CONSTRAINTS a
  WHERE a.CONSTRAINT_TYPE IN ('PRIMARY KEY', 'UNIQUE')
    AND table_schema NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
    ))
  AND table_schema NOT IN (
      'mysql',
      'information_schema',
      'performance_schema',
      'sys',
      '__recycle_bin__'
  );


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="top10_tb_size"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.6 占用空间最大的前10张大表</b></font>' >> /tmp/dbpatroller_report_mysql.html

/* 
1、表和索引在同一个文件中，例如sbtest6.ibd文件中包括了索引和数据
2、主键索引的大小就是数据大小
3、SQL查询出来的总大小应该减去datafree才是真实的占用空间
*/

-- 3.1.6 占用空间最大的前10张大表
SELECT
        table_schema AS db_name,
        table_name AS table_name,
        a.TABLE_TYPE,
        a.`ENGINE`,
        a.CREATE_TIME,
        a.UPDATE_TIME,
        a.TABLE_COLLATION,
        table_rows AS table_rows,
        TRUNCATE(a.DATA_LENGTH / 1024 / 1024, 2 ) AS tb_size_mb,
        TRUNCATE( index_length / 1024 / 1024, 2 ) AS index_size_mb,
        TRUNCATE( ( data_length + index_length ) / 1024 / 1024, 2 ) AS all_size_mb,
  TRUNCATE( a.DATA_FREE / 1024 / 1024, 2 ) AS free_size_mb,
  TRUNCATE(f.filesize_M,2) AS disk_size_mb
FROM information_schema.TABLES a
LEFT  JOIN
    (SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(b.file_name,'/',-2),'/',1) AS db_name,
                        REPLACE(SUBSTRING_INDEX(SUBSTRING_INDEX(b.file_name,'/',-2),'/',-1),'.ibd','') AS tb_name,
                        b.file_name,
                        TRUNCATE((total_extents*EXTENT_SIZE)/1024/1024,2) filesize_M
                        FROM  information_schema.FILES b
                        WHERE b.file_type NOT IN ('UNDO LOG')
                        ORDER BY filesize_M DESC LIMIT 0,10 
                        ) f
ON ( a.TABLE_SCHEMA= f.db_name AND a.TABLE_NAME=f.tb_name )
ORDER BY        ( data_length + index_length ) DESC
LIMIT 0,10;
 




notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="top10_idx_size"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.6 占用空间最大的前10个索引</b></font>' >> /tmp/dbpatroller_report_mysql.html

select 
iis.database_name, 
iis.table_name, 
iis.index_name, 
round((iis.stat_value*@@innodb_page_size)/1024/1024, 2) SizeMB, 
-- round(((100/(SELECT INDEX_LENGTH FROM INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_NAME = iis.table_name and t.TABLE_SCHEMA = iis.database_name))*(stat_value*@@innodb_page_size)), 2) `Percentage`,
s.NON_UNIQUE,
s.INDEX_TYPE,
GROUP_CONCAT(s.COLUMN_NAME order by SEQ_IN_INDEX) COLUMN_NAME
from (select * from mysql.innodb_index_stats 
				WHERE index_name  not in ('PRIMARY','GEN_CLUST_INDEX') and stat_name='size' 
				order by (stat_value*@@innodb_page_size) desc limit 10
			) iis 
left join INFORMATION_SCHEMA.STATISTICS s
on (iis.database_name=s.TABLE_SCHEMA and iis.table_name=s.TABLE_NAME and iis.index_name=s.INDEX_NAME)
GROUP BY iis.database_name,iis.TABLE_NAME,iis.INDEX_NAME,(iis.stat_value*@@innodb_page_size),s.NON_UNIQUE,s.INDEX_TYPE
order by (stat_value*@@innodb_page_size) desc;



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="all_engines"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.7 所有存储引擎列表</b></font>' >> /tmp/dbpatroller_report_mysql.html
show engines;
-- SELECT * from information_schema.`ENGINES`;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="engines_db"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.8 存储引擎和DB的数量关系 </b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT a.`ENGINE`,count( * ) counts 
FROM    information_schema.`TABLES` a 
WHERE   a.table_schema NOT IN (
    'mysql',
    'information_schema',
    'performance_schema',
    'sys',
    '__recycle_bin__'
  )
GROUP BY a.`ENGINE`;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
SELECT  a.TABLE_SCHEMA,
	a.`ENGINE`,
	count( * ) counts 
FROM    information_schema.`TABLES` a 
WHERE   a.table_schema NOT IN (
    'mysql',
    'information_schema',
    'performance_schema',
    'sys',
    '__recycle_bin__'
  )
GROUP BY  a.TABLE_SCHEMA,a.`ENGINE` 
ORDER BY a.TABLE_SCHEMA;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="ALL_USES"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.9 查询所有用户</b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT 
t1.host,
t1.user,
t1.plugin,
t1.password_expired,
t1.password_last_changed,
t1.password_lifetime,
t1.account_locked
FROM mysql.user t1
ORDER BY t1.user;




notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="IMPORTANT_INIT"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.1.10 一些重要的参数 </b></font>' >> /tmp/dbpatroller_report_mysql.html
show global VARIABLES where  VARIABLE_NAME in ('datadir','SQL_MODE','socket','TIME_ZONE','tx_isolation','autocommit','innodb_lock_wait_timeout','max_connections','max_user_connections','slow_query_log','log_output','slow_query_log_file','long_query_time','log_queries_not_using_indexes','log_throttle_queries_not_using_indexes','log_throttle_queries_not_using_indexes','pid_file','log_error','lower_case_table_names','innodb_buffer_pool_size','innodb_flush_log_at_trx_commit','read_only', 'log_slave_updates','innodb_io_capacity','query_cache_type','query_cache_size','max_connect_errors','server_id','innodb_file_per_table') ;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="ck_user_login"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>●   3.1.11 多维度查看用户及主机信息</b></font>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 查看当前连接到数据库的用户和Host </b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT DISTINCT USER,HOST FROM `information_schema`.`PROCESSLIST` P WHERE P.USER NOT in ('root','repl','system user');

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="ALL_link_user_host_per"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 查看每个host的当前连接数和总连接数 </b></font>' >> /tmp/dbpatroller_report_mysql.html
-- 系统表performance_schema.hosts在MySQL 5.6.3版本中引入，用来保存MySQL服务器启动后的连接情况。
SELECT * FROM performance_schema.hosts;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="ALL_link_user_host_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 按照登录用户+登录服务器查看登录信息 </b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT
     USER,
     SUBSTRING_INDEX(p.host, ':', 1) AS 'login_ip',
     COUNT(*) as 'login_count'
  FROM
    `information_schema`.`PROCESSLIST` p
  WHERE 1=1 
   AND  p.USER NOT IN ('root', 'repl', 'system user') 
   GROUP BY CONCAT(p.user,login_ip);

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="ALL_link_user_host_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 按照登录用户+数据库+登录服务器查看登录信息 </b></font>' >> /tmp/dbpatroller_report_mysql.html
-- 按照登录用户+数据库+登录服务器查看登录信息
SELECT
  db AS 'db_name',
  USER AS 'login_user',
  SUBSTRING_INDEX(p.host, ':', 1) AS 'login_ip',
  COUNT(*) AS 'login_count'
FROM
  `information_schema`.`PROCESSLIST` p
WHERE 1 = 1
  AND p.USER NOT IN ('root', 'repl', 'system user')
GROUP BY p.db,
  p.user,
  login_ip;





notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<center>[<a class="noLink" href="#directory">回到目录</a>]</center><p></hr>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr><p><p>' >> /tmp/dbpatroller_report_mysql.html



-- +----------------------------------------------------------------------------+
-- |                           - Lock info -                                    |
-- +----------------------------------------------------------------------------+
notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="lOCK_INFO"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<font size="+2" color="00CCFF"><b>● 3.2 锁情况</b></font><hr align="left" width="800">' >> /tmp/dbpatroller_report_mysql.html

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="all_processlist"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.1 查询所有线程（排除sleep线程）</b></font>' >> /tmp/dbpatroller_report_mysql.html
-- show full processlist;
-- SELECT * FROM information_schema.`PROCESSLIST`;
select * from information_schema.`PROCESSLIST`  a where a.command<>'Sleep' and a.id<>CONNECTION_id() ;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
SELECT * FROM performance_schema.threads a where a.type!='BACKGROUND' and a.PROCESSLIST_COMMAND<>'Sleep'  and a.PROCESSLIST_ID<>CONNECTION_id() ;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="all_processlist_sleep"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.2 sleep线程TOP20</b></font>' >> /tmp/dbpatroller_report_mysql.html
select * from information_schema.`PROCESSLIST`  a where a.command='Sleep' order by time desc limit 20 ;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
SELECT * FROM performance_schema.threads a where a.type!='BACKGROUND' and a.PROCESSLIST_COMMAND='Sleep'   order by a.PROCESSLIST_time desc limit 20 ;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="process_use"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.3 当前是否有锁表</b></font>' >> /tmp/dbpatroller_report_mysql.html
show open tables where in_use > 0;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="process_use"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.4 行锁争用情况</b></font>' >> /tmp/dbpatroller_report_mysql.html
show status like 'innodb_row_lock%';

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="Innodb_running"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.5 查询InnoDB存储引擎的运行时信息，包括死锁的详细信息</b></font>' >> /tmp/dbpatroller_report_mysql.html
show engine innodb status;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="innodb_trx_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.6 查看当前状态产生的InnoDB锁，仅在有锁等待时有结果输出</b></font>' >> /tmp/dbpatroller_report_mysql.html
select * from performance_schema.data_locks;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="innodb_trx_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.7 查看当前状态产生的InnoDB锁等待，仅在有锁等待时有结果输出</b></font>' >> /tmp/dbpatroller_report_mysql.html
select * from performance_schema.data_lock_waits;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="innodb_trx_active"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.8 当前Innodb内核中的当前活跃（active）事务 </b></font>' >> /tmp/dbpatroller_report_mysql.html
select * from information_schema.innodb_trx;



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="innodb_lock_detail"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.9 锁详情 </b></font>' >> /tmp/dbpatroller_report_mysql.html
WITH waiting_trx AS
(SELECT
  r.trx_isolation_level AS waiting_isolation_level,
  r.trx_id AS waiting_trx_id,
  r.trx_mysql_thread_id AS waiting_thread_id,
  r.trx_state AS waiting_state,
  lr.lock_mode AS waiting_lock_mode,
  lr.lock_type AS waiting_lock_type,
  lr.OBJECT_SCHEMA AS waiting_schema,
  lr.OBJECT_NAME AS waiting_table,
  lr.INDEX_NAME AS waiting_index,
  r.trx_query AS waiting_query,
  w.blocking_thread_id
FROM
  performance_schema.data_lock_waits w
  JOIN performance_schema.threads wt
    ON wt.thread_id = w.requesting_thread_id
  JOIN information_schema.innodb_trx r
    ON r.trx_mysql_thread_id = wt.processlist_id
  JOIN performance_schema.data_locks lr
    ON lr.engine_transaction_id = r.trx_id
    AND lr.thread_id = w.requesting_thread_id),
blocking_trx AS
(SELECT
  b.trx_id AS blocking_trx_id,
  b.trx_mysql_thread_id AS blocking_thread_id,
  b.trx_state AS blocking_state,
  lb.lock_mode AS blocking_lock_mode,
  lb.lock_type AS blocking_lock_type,
  lb.OBJECT_SCHEMA AS blocking_schema,
  lb.OBJECT_NAME AS blocking_table,
  lb.INDEX_NAME AS blocking_index,
  b.trx_query AS blocking_query
FROM
  performance_schema.data_lock_waits w
  JOIN performance_schema.threads bt
    ON bt.thread_id = w.blocking_thread_id
  JOIN information_schema.innodb_trx b
    ON b.trx_mysql_thread_id = bt.processlist_id
  JOIN performance_schema.data_locks lb
    ON lb.engine_transaction_id = b.trx_id
    AND lb.thread_id = w.blocking_thread_id)
SELECT
  wt.waiting_isolation_level,
  wt.waiting_trx_id,
  wt.waiting_thread_id,
  wt.waiting_state,
  wt.waiting_lock_mode,
  wt.waiting_lock_type,
  wt.waiting_schema,
  wt.waiting_table,
  wt.waiting_index,
  wt.waiting_query,
  bt.blocking_trx_id,
  bt.blocking_thread_id,
  bt.blocking_state,
  bt.blocking_lock_mode,
  bt.blocking_lock_type,
  bt.blocking_schema,
  bt.blocking_table,
  bt.blocking_index,
  bt.blocking_query
FROM
  waiting_trx wt
  JOIN blocking_trx bt
    ON wt.blocking_thread_id = bt.blocking_thread_id;




notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="mdl_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.10 元数据锁的相关信息 </b></font>' >> /tmp/dbpatroller_report_mysql.html
-- 临时：UPDATE performance_schema.setup_instruments SET ENABLED = 'YES', TIMED = 'YES' WHERE NAME = 'wait/lock/metadata/sql/mdl';
-- 永久：[mysqld]performance-schema-instrument='wait/lock/metadata/sql/mdl=ON'
select * from performance_schema.setup_instruments WHERE name='wait/lock/metadata/sql/mdl';
notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
-- 从5.7开始
SELECT
    locked_schema,
    locked_table,
    locked_type,
    waiting_processlist_id,
    waiting_age,
    waiting_query,
    waiting_state,
    blocking_processlist_id,
    blocking_age,
    substring_index(sql_text,"transaction_begin;" ,-1) AS blocking_query,
    sql_kill_blocking_connection
FROM
    (
        SELECT
            b.OWNER_THREAD_ID AS granted_thread_id,
            a.OBJECT_SCHEMA AS locked_schema,
            a.OBJECT_NAME AS locked_table,
            "Metadata Lock" AS locked_type,
            c.PROCESSLIST_ID AS waiting_processlist_id,
            c.PROCESSLIST_TIME AS waiting_age,
            c.PROCESSLIST_INFO AS waiting_query,
            c.PROCESSLIST_STATE AS waiting_state,
            d.PROCESSLIST_ID AS blocking_processlist_id,
            d.PROCESSLIST_TIME AS blocking_age,
            d.PROCESSLIST_INFO AS blocking_query,
            concat('KILL ', d.PROCESSLIST_ID) AS sql_kill_blocking_connection
        from performance_schema.metadata_locks a
        JOIN performance_schema.metadata_locks b 
		ON a.OBJECT_SCHEMA = b.OBJECT_SCHEMA
        AND a.OBJECT_NAME = b.OBJECT_NAME
        AND a.lock_status = 'PENDING'
        AND b.lock_status = 'GRANTED'
        AND a.OWNER_THREAD_ID <> b.OWNER_THREAD_ID
        AND a.lock_type = 'EXCLUSIVE'
        JOIN performance_schema.threads c ON a.OWNER_THREAD_ID = c.THREAD_ID
        JOIN performance_schema.threads d ON b.OWNER_THREAD_ID = d.THREAD_ID
    ) t1,
    (
        SELECT
            thread_id,
            group_concat(   CASE WHEN EVENT_NAME = 'statement/sql/begin' THEN "transaction_begin" ELSE sql_text END ORDER BY event_id SEPARATOR ";" ) AS sql_text
        FROM
            performance_schema.events_statements_history
        GROUP BY thread_id
    ) t2
WHERE
    t1.granted_thread_id = t2.thread_id;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
-- 从5.7开始
SELECT
    a.OBJECT_SCHEMA AS locked_schema,
    a.OBJECT_NAME AS locked_table,
    "Metadata Lock" AS locked_type,
    c.PROCESSLIST_ID AS waiting_processlist_id,
    c.PROCESSLIST_TIME AS waiting_age,
    c.PROCESSLIST_INFO AS waiting_query,
    c.PROCESSLIST_STATE AS waiting_state,
    d.PROCESSLIST_ID AS blocking_processlist_id,
    d.PROCESSLIST_TIME AS blocking_age,
    d.PROCESSLIST_INFO AS blocking_query,
    concat('KILL ', d.PROCESSLIST_ID) AS sql_kill_blocking_connection
FROM
    performance_schema.metadata_locks a
JOIN performance_schema.metadata_locks b ON a.OBJECT_SCHEMA = b.OBJECT_SCHEMA
AND a.OBJECT_NAME = b.OBJECT_NAME
AND a.lock_status = 'PENDING'
AND b.lock_status = 'GRANTED'
AND a.OWNER_THREAD_ID <> b.OWNER_THREAD_ID
AND a.lock_type = 'EXCLUSIVE'
JOIN performance_schema.threads c ON a.OWNER_THREAD_ID = c.THREAD_ID
JOIN performance_schema.threads d ON b.OWNER_THREAD_ID = d.THREAD_ID;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
SELECT ps.*,  lock_summary.lock_summary  FROM sys.processlist ps  INNER JOIN (SELECT owner_thread_id,  GROUP_CONCAT(  DISTINCT CONCAT(mdl.LOCK_STATUS, ' ', mdl.lock_type, ' on ', IF(mdl.object_type='USER LEVEL LOCK', CONCAT(mdl.object_name, ' (user lock)'), CONCAT(mdl.OBJECT_SCHEMA, '.', mdl.OBJECT_NAME)))  ORDER BY mdl.object_type ASC, mdl.LOCK_STATUS ASC, mdl.lock_type ASC  SEPARATOR '\n'  ) as lock_summary FROM performance_schema.metadata_locks mdl GROUP BY owner_thread_id) lock_summary ON (ps.thd_id=lock_summary.owner_thread_id);

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
select * from sys.schema_table_lock_waits;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="mdl_status"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.2.11 查看锁参数的状态</b></font>' >> /tmp/dbpatroller_report_mysql.html
show status like '%lock%';

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<center>[<a class="noLink" href="#directory">回到目录</a>]</center><p>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr><p><p>' >> /tmp/dbpatroller_report_mysql.html




-- +----------------------------------------------------------------------------+
-- |                           - SQL info -                                     |
-- +----------------------------------------------------------------------------+
notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<font size="+2" color="00CCFF"><b>● 3.3 SQL部分</b></font><hr align="left" width="800">' >> /tmp/dbpatroller_report_mysql.html



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="SQL_run_long"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.1 跟踪长时间操作的进度 </b></font>' >> /tmp/dbpatroller_report_mysql.html
-- select * from performance_schema.events_stages_current;
SELECT
  t1.THREAD_ID,
  t1.PROCESSLIST_USER,
  t2.`EVENT_NAME`,
  t1.PROCESSLIST_HOST,
  t1.PROCESSLIST_DB,
  t1.PROCESSLIST_COMMAND,
  t1.PROCESSLIST_TIME,
  t1.PROCESSLIST_STATE,
  t2.`SQL_TEXT`,
  t2.`DIGEST`
FROM
  performance_schema.threads t1
  INNER JOIN performance_schema.events_statements_current t2 
  ON t1.`THREAD_ID`=t2.`THREAD_ID`
WHERE 1=1 
AND t1.PROCESSLIST_USER NOT IN ('replicator','aliyun_root','aurora') 
AND t1.PROCESSLIST_TIME > 100
ORDER BY t1.PROCESSLIST_TIME DESC
LIMIT 0,20;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="SQL_run_long_95"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.2 查看平均执行时间值大于95%的平均执行时间的语句（可近似地认为是平均执行时间超长的语句），默认情况下按照语句平均延迟(执行时间)降序排序 </b></font>' >> /tmp/dbpatroller_report_mysql.html
-- 平均执行时间超长的语句倒序top10
SELECT sys.format_statement(DIGEST_TEXT) AS QUERY,
  SCHEMA_NAME AS db,
  IF(SUM_NO_GOOD_INDEX_USED > 0 OR SUM_NO_INDEX_USED > 0, '*', '') AS full_scan,
  COUNT_STAR AS exec_count,
  SUM_ERRORS AS err_count,
  SUM_WARNINGS AS warn_count,
  sys.format_time(SUM_TIMER_WAIT) AS total_latency,
  sys.format_time(MAX_TIMER_WAIT) AS max_latency,
  sys.format_time(AVG_TIMER_WAIT) AS avg_latency,
  SUM_ROWS_SENT AS rows_sent,
  ROUND(IFNULL(SUM_ROWS_SENT / NULLIF(COUNT_STAR, 0), 0)) AS rows_sent_avg,
  SUM_ROWS_EXAMINED AS rows_examined,
  ROUND(IFNULL(SUM_ROWS_EXAMINED / NULLIF(COUNT_STAR, 0), 0)) AS rows_examined_avg,
  FIRST_SEEN AS first_seen,
  LAST_SEEN AS last_seen,
  DIGEST AS digest
FROM performance_schema.events_statements_summary_by_digest stmts
JOIN sys.x$ps_digest_95th_percentile_by_avg_us AS top_percentile
ON ROUND(stmts.avg_timer_wait/1000000) >= top_percentile.avg_us
ORDER BY AVG_TIMER_WAIT DESC 
LIMIT 0,10;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.3 查看当前正在执行的语句进度信息 </b></font>' >> /tmp/dbpatroller_report_mysql.html
select * from sys.session where conn_id!=connection_id() and trx_state='ACTIVE';


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.4 查看已经执行完的语句相关统计信息 </b></font>' >> /tmp/dbpatroller_report_mysql.html
select * from sys.session where conn_id!=connection_id() and trx_state='COMMITTED';


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_info_tmp1"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.5 查看使用了临时表的语句，默认情况下按照磁盘临时表数量和内存临时表数量进行降序排序 </b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT sys.format_statement(DIGEST_TEXT) AS query,
  SCHEMA_NAME as db,
  COUNT_STAR AS exec_count,
  sys.format_time(SUM_TIMER_WAIT) as total_latency,
  SUM_CREATED_TMP_TABLES AS memory_tmp_tables,
  SUM_CREATED_TMP_DISK_TABLES AS disk_tmp_tables,
  ROUND(IFNULL(SUM_CREATED_TMP_TABLES / NULLIF(COUNT_STAR, 0), 0)) AS avg_tmp_tables_per_query,
  ROUND(IFNULL(SUM_CREATED_TMP_DISK_TABLES / NULLIF(SUM_CREATED_TMP_TABLES, 0), 0) * 100) AS tmp_tables_to_disk_pct,
  FIRST_SEEN as first_seen,
  LAST_SEEN as last_seen,
  DIGEST AS digest
FROM performance_schema.events_statements_summary_by_digest
WHERE SUM_CREATED_TMP_TABLES > 0
ORDER BY SUM_CREATED_TMP_DISK_TABLES DESC, SUM_CREATED_TMP_TABLES DESC limit 10; 

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_info_tmp2"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.6 有临时表的前10条SQL语句</b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT * FROM sys.statement_analysis WHERE tmp_tables > 0 ORDER BY tmp_tables DESC LIMIT 10;



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_info_disk_sort"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.7 查看执行了文件排序的语句，默认情况下按照语句总延迟时间（执行时间）降序排序 </b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT sys.format_statement(DIGEST_TEXT) AS query,
  SCHEMA_NAME db,
  COUNT_STAR AS exec_count,
  sys.format_time(SUM_TIMER_WAIT) AS total_latency,
  SUM_SORT_MERGE_PASSES AS sort_merge_passes,
  ROUND(IFNULL(SUM_SORT_MERGE_PASSES / NULLIF(COUNT_STAR, 0), 0)) AS avg_sort_merges,
  SUM_SORT_SCAN AS sorts_using_scans,
  SUM_SORT_RANGE AS sort_using_range,
  SUM_SORT_ROWS AS rows_sorted,
  ROUND(IFNULL(SUM_SORT_ROWS / NULLIF(COUNT_STAR, 0), 0)) AS avg_rows_sorted,
  FIRST_SEEN as first_seen,
  LAST_SEEN as last_seen,
  DIGEST AS digest
FROM performance_schema.events_statements_summary_by_digest
WHERE SUM_SORT_ROWS > 0
ORDER BY SUM_TIMER_WAIT DESC limit 10; 



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sqL_cost_all"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.8 查询SQL的整体消耗百分比 </b></font>' >> /tmp/dbpatroller_report_mysql.html
  SELECT state,
       SUM(duration) AS total_r,
       ROUND(100 * SUM(duration) / (SELECT SUM(duration) FROM information_schema.profiling  WHERE 1=1 
       -- query_id = 1
       ),2) AS 'pct_r(%)',
       COUNT(*) AS calls,
       SUM(duration) / COUNT(*) AS "r/call"
  FROM information_schema.profiling
 WHERE 1=1 
 -- and query_id = 1
 GROUP BY state
 ORDER BY total_r DESC;





notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sqL_exec_count_top10"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.9 执行次数Top10</b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT
  *
FROM
  sys.statement_analysis
WHERE full_scan = '*'
AND db IS NOT NULL
AND QUERY IS NOT NULL
AND db NOT IN (
      'mysql',
      'sys',
      'INFORMATION_SCHEMA',
      'PERFORMANCE_SCHEMA',
      'maindb_cross_data'
    )
ORDER BY exec_count DESC
LIMIT 0,10;





notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sqL_full_scan"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.10 使用全表扫描的SQL语句</b></font>' >> /tmp/dbpatroller_report_mysql.html
  SELECT object_schema,
    object_name, -- 表名
    count_read AS rows_full_scanned,  -- 全表扫描的总数据行数
    sys.format_time(sum_timer_wait) AS latency -- 完整的表扫描操作的总延迟时间（执行时间）
  FROM performance_schema.table_io_waits_summary_by_index_usage
  WHERE index_name IS NULL
  AND count_read > 0
  ORDER BY count_read DESC limit 10;

-- -- 如果性能模式已启用，查询进行了全表扫描的SQL语句
-- SELECT
--   schema_name,
--   digest,
--   digest_text,
--   count_star AS execution_count,
--   sum_rows_sent AS rows_sent,
--   sum_rows_examined AS rows_examined,
--   sum_no_index_used AS full_scans
-- FROM
--   performance_schema.events_statements_summary_by_digest
-- WHERE
--   sum_no_index_used > 0
--   AND schema_name NOT IN ('mysql', 'information_schema', 'performance_schema', 'sys')
-- ORDER BY
--   sum_no_index_used DESC
--   LIMIT 0,20;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_no_best_index"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.11 查看全表扫描或者没有使用到最优索引的语句（经过标准化转化的语句文本），默认情况下按照全表扫描次数与语句总次数百分比和语句总延迟时间(执行时间)降序排序 </b></font>' >> /tmp/dbpatroller_report_mysql.html

SELECT sys.format_statement(DIGEST_TEXT) AS query,
  SCHEMA_NAME as db,
  COUNT_STAR AS exec_count,
  sys.format_time(SUM_TIMER_WAIT) AS total_latency,
  SUM_NO_INDEX_USED AS no_index_used_count,
  SUM_NO_GOOD_INDEX_USED AS no_good_index_used_count,
  ROUND(IFNULL(SUM_NO_INDEX_USED / NULLIF(COUNT_STAR, 0), 0) * 100) AS no_index_used_pct,
  SUM_ROWS_SENT AS rows_sent,
  SUM_ROWS_EXAMINED AS rows_examined,
  ROUND(SUM_ROWS_SENT/COUNT_STAR) AS rows_sent_avg,
  ROUND(SUM_ROWS_EXAMINED/COUNT_STAR) AS rows_examined_avg,
  FIRST_SEEN as first_seen,
  LAST_SEEN as last_seen,
  DIGEST AS digest
FROM performance_schema.events_statements_summary_by_digest
WHERE (SUM_NO_INDEX_USED > 0
OR SUM_NO_GOOD_INDEX_USED > 0)
AND DIGEST_TEXT NOT LIKE 'SHOW%'
ORDER BY no_index_used_pct DESC, total_latency DESC limit 10; 




notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_error_worings"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b> ● 3.3.12 查看产生错误或警告的语句，默认情况下，按照错误数量和警告数量降序排序 </b></font>' >> /tmp/dbpatroller_report_mysql.html

SELECT sys.format_statement(DIGEST_TEXT) AS query,
  SCHEMA_NAME as db,
  COUNT_STAR AS exec_count,
  SUM_ERRORS AS errors,
  IFNULL(SUM_ERRORS / NULLIF(COUNT_STAR, 0), 0) * 100 as error_pct,
  SUM_WARNINGS AS warnings,
  IFNULL(SUM_WARNINGS / NULLIF(COUNT_STAR, 0), 0) * 100 as warning_pct,
  FIRST_SEEN as first_seen,
  LAST_SEEN as last_seen,
  DIGEST AS digest
FROM performance_schema.events_statements_summary_by_digest
WHERE SUM_ERRORS > 0
OR SUM_WARNINGS > 0
ORDER BY SUM_ERRORS DESC, SUM_WARNINGS DESC limit 10; 


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<center>[<a class="noLink" href="#directory">回到目录</a>]</center><p>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr><p><p>' >> /tmp/dbpatroller_report_mysql.html




-- +----------------------------------------------------------------------------+
-- |                           - Index info -                                   |
-- +----------------------------------------------------------------------------+
#index_info
notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="index_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<font size="+2" color="00CCFF"><b>● 3.4 索引部分</b></font><hr align="left" width="800">' >> /tmp/dbpatroller_report_mysql.html



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_redundant_indexes"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.4.1 冗余索引</b></font>' >> /tmp/dbpatroller_report_mysql.html
-- 若库很大，这个视图可能查询不出结果，可以摁一次“ctrl+c”跳过这个SQL
-- select * from sys.schema_redundant_indexes;

-- SELECT
--  COUNT(*)
-- FROM
--   sys.schema_redundant_indexes a
-- WHERE a.table_schema NOT IN (
--     'mysql',
--     'information_schema',
--     'performance_schema',
--     'sys',
--     '__recycle_bin__'
--   );


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="sql_unused_indexes"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.4.2 无效索引（从未使用过的索引）</b></font>' >> /tmp/dbpatroller_report_mysql.html
-- select * from sys.schema_unused_indexes;
SELECT
  *
FROM
  sys.schema_unused_indexes t1
WHERE object_schema NOT IN (
    'sys',
    'performance_schema',
    'information_schema',
    'mysql',
   '__recycle_bin__'
  );




notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="index_qfd"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.4.3 每张表的索引区分度（前100条）</b></font>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+0.2" face="Courier New,Helvetica,Geneva,sans-serif">   区分度越接近1，表示区分度越高；低于0.1，则说明区分度较差，开发者应该重新评估SQL语句涉及的字段，选择区分度高的多个字段创建索引</font>' >> /tmp/dbpatroller_report_mysql.html

SELECT
i.database_name AS db,
i.table_name AS t_name,
i.index_name AS index_name,
i.stat_description AS cols,
i.stat_value AS defferRows,
t.n_rows AS 'rows',
ROUND(((i.stat_value / IFNULL(IF(t.n_rows < i.stat_value,i.stat_value,t.n_rows),0.01))),2) AS sel_persent
-- select count(*)
FROM mysql.innodb_index_stats i
INNER JOIN mysql.innodb_table_stats t
ON i.database_name = t.database_name AND i.table_name= t.table_name
WHERE i.index_name != 'PRIMARY' AND i.stat_name LIKE '%n_diff_pfx%'
AND ROUND(((i.stat_value / IFNULL(IF(t.n_rows < i.stat_value,i.stat_value,t.n_rows),0.01))),2)<0.1
AND t.n_rows !=0
AND i.stat_value !=0
AND i.database_name NOT IN ('mysql', 'information_schema', 'sys', 'performance_schema','__recycle_bin__')
LIMIT 0,100;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<center>[<a class="noLink" href="#directory">回到目录</a>]</center><p>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr><p><p>' >> /tmp/dbpatroller_report_mysql.html







-- +----------------------------------------------------------------------------+
-- |                           - MySQL Replication -                            |
-- +----------------------------------------------------------------------------+
notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="slave_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<font size="+2" color="00CCFF"><b>● 3.5 主从情况</b></font><hr align="left" width="800">' >> /tmp/dbpatroller_report_mysql.html


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="SLAVE_IMPORTANT_INIT"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.5.1 主从复制涉及到的重要参数 </b></font>' >> /tmp/dbpatroller_report_mysql.html
show global VARIABLES where  VARIABLE_NAME in  ('server_id','server_uuid','log_bin','log_bin_basename','sql_log_bin','log_bin_index','log_slave_updates','read_only','slave_skip_errors','max_allowed_packet','slave_max_allowed_packet','auto_increment_increment','auto_increment_offset','sync_binlog','binlog_format','expire_logs_days','max_binlog_size','slave_skip_errors','sql_slave_skip_counter','slave_exec_mode') ;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="slave_processlist"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.5.2 主从同步状态</b></font>' >> /tmp/dbpatroller_report_mysql.html
show slave status\G;



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<p>' >> /tmp/dbpatroller_report_mysql.html
SELECT * FROM information_schema.`PROCESSLIST` a where a.USER='system user' or a.command='Binlog Dump'; 



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="master_info_status"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.5.3 主库端查看所有从库</b></font>' >> /tmp/dbpatroller_report_mysql.html
show slave hosts;


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="master_info_status"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.5.3.1 主库状态监测</b></font>' >> /tmp/dbpatroller_report_mysql.html
show master status;



notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="slave_info_status"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.5.4 从库状态监测（需要在从库执行才有数据）</b></font>' >> /tmp/dbpatroller_report_mysql.html
show slave status;

select rcc.CHANNEL_NAME,rcc.`HOST`,rcc.`PORT`,rcc.`USER`,rcc.CONNECTION_RETRY_COUNT,rcc.CONNECTION_RETRY_INTERVAL,
rcs.SOURCE_UUID,rcs.THREAD_ID,rcs.SERVICE_STATE,rcs.COUNT_RECEIVED_HEARTBEATS,rcs.LAST_HEARTBEAT_TIMESTAMP,rcs.LAST_ERROR_NUMBER,rcs.LAST_ERROR_MESSAGE,rcs.LAST_ERROR_TIMESTAMP
from performance_schema.replication_connection_configuration rcc, 
     performance_schema.replication_connection_status rcs
where rcc.CHANNEL_NAME=rcs.CHANNEL_NAME;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="mgr_info_status"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.5.5 MGR集群状态监测</b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT CHANNEL_NAME,substring(MEMBER_ID,1,8) MEMBER_ID,MEMBER_HOST,MEMBER_PORT,MEMBER_STATE,MEMBER_ROLE,MEMBER_VERSION FROM
performance_schema.replication_group_members t1 order by t1.member_role;

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<center>[<a class="noLink" href="#directory">回到目录</a>]</center><p>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr><p><p>' >> /tmp/dbpatroller_report_mysql.html




-- +----------------------------------------------------------------------------+
-- |                           - db performance info -                                   |
-- +----------------------------------------------------------------------------+

notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="db_performance_info"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<font size="+2" color="00CCFF"><b>● 3.6 数据库性能</b></font><hr align="left" width="800">' >> /tmp/dbpatroller_report_mysql.html


notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="db_per_config_stats"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.6.1 性能参数统计</b></font>' >> /tmp/dbpatroller_report_mysql.html

-- 查询数据库的性能参数统计
SHOW GLOBAL STATUS WHERE VARIABLE_NAME IN (
  'connections',
  'uptime',
  'com_select',
  'com_insert',
  'com_delete',
  'slow_queries',
  'Created_tmp_tables',
  'Created_tmp_files',
  'Created_tmp_disk_tables',
  'table_cache',
  'Handler_read_rnd_next',
  'Table_locks_immediate',
  'Table_locks_waited',
  'Open_files',
  'Opened_tables',
  'Sort_merge_passes',
  'Sort_range',
  'Sort_rows',
  'Sort_scan'
);



notee
-- tee /tmp/dbpatroller_report_mysql.html;
-- system echo '<center>[<a class="noLink" href="#directory">回到目录</a>]</center><p>' >> /tmp/dbpatroller_report_mysql.html
-- system echo '<hr><p><p>' >> /tmp/dbpatroller_report_mysql.html



-- notee
tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="Auto_increment"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.6.2 自增ID的使用情况（前20条）</b></font>' >> /tmp/dbpatroller_report_mysql.html
SELECT
  table_schema,
  table_name,
  ENGINE,
  AUTO_INCREMENT
FROM
  information_schema.tables a
WHERE TABLE_SCHEMA NOT IN (
    'mysql',
    'information_schema',
    'sys',
    'performance_schema',
    '__recycle_bin__'
  )
  AND a.AUTO_INCREMENT <> ''
ORDER BY a.AUTO_INCREMENT DESC
LIMIT 0,20;


notee


tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="tmpdir"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<p><font size="+1" face="Courier New,Helvetica,Geneva,sans-serif" color="#336699"><b>● 3.6.3 tmpdir路径检查</b></font>' >> /tmp/dbpatroller_report_mysql.html
show variables like 'tmpdir%';

notee

tee /tmp/dbpatroller_report_mysql.html;
system echo '<a name="html_bottom_link"></a>' >> /tmp/dbpatroller_report_mysql.html
system echo '<center>[<a class="noLink" href="#directory">回到目录</a>]</center><p>' >> /tmp/dbpatroller_report_mysql.html
system echo '<hr><p><p>' >> /tmp/dbpatroller_report_mysql.html


system mv /tmp/dbpatroller_report_mysql.html /tmp/Sunac_Dbpatroller_Mysql_Report_`date "+%Y%m%d%H%M%S"`.html
quit
